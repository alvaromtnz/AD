const W = 800;
const H = 500;

class Level1 extends Phaser.Scene {
  constructor() {
    super("Level1");
  }

  create() {
    this.goalTaken = false;
    this.winLayer = null;

    const ground = this.add.rectangle(W / 2, H - 20, W, 40, 0x2b395f);
    this.physics.add.existing(ground, true);

    const p1 = this.add.rectangle(220, 380, 200, 25, 0x2b395f);
    const p2 = this.add.rectangle(480, 300, 200, 25, 0x2b395f);
    const p3 = this.add.rectangle(680, 220, 180, 25, 0x2b395f);
    this.physics.add.existing(p1, true);
    this.physics.add.existing(p2, true);
    this.physics.add.existing(p3, true);

    this.player = this.add.rectangle(120, H - 120, 32, 32, 0xffffff);
    this.physics.add.existing(this.player);
    this.player.body.setCollideWorldBounds(true);

    this.physics.add.collider(this.player, ground);
    this.physics.add.collider(this.player, p1);
    this.physics.add.collider(this.player, p2);
    this.physics.add.collider(this.player, p3);

    const hazards = this.physics.add.staticGroup();

    const h1 = this.add.rectangle(330, H - 56, 90, 12, 0xff2d88);
    this.physics.add.existing(h1, true);
    hazards.add(h1);

    const h2 = this.add.rectangle(500, 270, 70, 12, 0xff2d88);
    this.physics.add.existing(h2, true);
    hazards.add(h2);

    this.goal = this.add.rectangle(700, 180, 18, 18, 0xffd34d);
    this.physics.add.existing(this.goal, true);

    this.exitZone = this.add.rectangle(760, 120, 70, 40, 0x20ff9a);
    this.exitZone.setAlpha(0.35);
    this.physics.add.existing(this.exitZone, true);

    this.physics.add.overlap(this.player, hazards, () => this.scene.restart());

    this.physics.add.overlap(this.player, this.goal, () => {
      if (this.goalTaken) return;
      this.goalTaken = true;
      this.goal.destroy();
      this.exitZone.setAlpha(0.9);
      this.hudMsg.setText("OBJETIVO CONSEGUIDO");
    });

    this.physics.add.overlap(this.player, this.exitZone, () => {
      if (!this.goalTaken) return;
      this.showWin();
    });

    this.cursors = this.input.keyboard.createCursorKeys();
    this.keyR = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R);

    this.hudTop = this.add.text(18, 14, "NIVEL 1  |  OBJETIVO: NO", {
      fontFamily: "Arial",
      fontSize: "18px",
      color: "#e6f0ff",
    });

    this.hudMsg = this.add.text(18, 40, "", {
      fontFamily: "Arial",
      fontSize: "18px",
      color: "#ffd34d",
    });

    this.add.text(18, 66, "R reinicia", {
      fontFamily: "Arial",
      fontSize: "16px",
      color: "#9fb3ff",
    });
  }

  update() {
    if (Phaser.Input.Keyboard.JustDown(this.keyR)) {
      this.scene.restart();
      return;
    }

    this.hudTop.setText(
      `NIVEL 1  |  OBJETIVO: ${this.goalTaken ? "SÍ" : "NO"}`
    );

    if (this.winLayer) {
      if (Phaser.Input.Keyboard.JustDown(this.keyEnter)) {
        this.scene.start("Level2");
      }
      return;
    }

    if (this.cursors.left.isDown) this.player.body.setVelocityX(-220);
    else if (this.cursors.right.isDown) this.player.body.setVelocityX(220);
    else this.player.body.setVelocityX(0);

    const jump =
      Phaser.Input.Keyboard.JustDown(this.cursors.up) ||
      Phaser.Input.Keyboard.JustDown(this.cursors.space);

    if (jump && this.player.body.blocked.down)
      this.player.body.setVelocityY(-420);

    if (this.player.y > H + 80) this.scene.restart();
  }

  showWin() {
    if (this.winLayer) return;

    this.player.body.setVelocity(0, 0);
    this.player.body.moves = false;

    const bg = this.add
      .rectangle(W / 2, H / 2, 560, 250, 0x111a2e)
      .setAlpha(0.98);

    const t1 = this.add
      .text(W / 2, H / 2 - 70, "NIVEL 1 COMPLETADO", {
        fontFamily: "Arial",
        fontSize: "26px",
        color: "#20ff9a",
      })
      .setOrigin(0.5);

    const t2 = this.add
      .text(W / 2, H / 2 - 20, "Pulsa ENTER para ir al Nivel 2", {
        fontFamily: "Arial",
        fontSize: "18px",
        color: "#e6f0ff",
      })
      .setOrigin(0.5);

    const t3 = this.add
      .text(W / 2, H / 2 + 35, "Pulsa R para reiniciar", {
        fontFamily: "Arial",
        fontSize: "18px",
        color: "#9fb3ff",
      })
      .setOrigin(0.5);

    this.keyEnter = this.input.keyboard.addKey(
      Phaser.Input.Keyboard.KeyCodes.ENTER
    );

    this.winLayer = { bg, t1, t2, t3 };
  }
}

class Level2 extends Phaser.Scene {
  constructor() {
    super("Level2");
  }

  create() {
    this.goalTaken = false;
    this.switchOn = false;
    this.switchLock = false;
    this.winLayer = null;

    const ground = this.add.rectangle(W / 2, H - 20, W, 40, 0x2b395f);
    this.physics.add.existing(ground, true);

    const base1 = this.add.rectangle(160, 390, 170, 25, 0x2b395f);
    const base2 = this.add.rectangle(340, 330, 170, 25, 0x2b395f);
    this.physics.add.existing(base1, true);
    this.physics.add.existing(base2, true);

    this.bridgeA = this.add.rectangle(520, 280, 140, 20, 0x2b395f);
    this.physics.add.existing(this.bridgeA, true);

    this.bridgeB = this.add.rectangle(640, 230, 180, 20, 0x2b395f);
    this.physics.add.existing(this.bridgeB, true);

    this.bridgeB.body.enable = false;
    this.bridgeB.setAlpha(0.2);

    this.player = this.add.rectangle(90, H - 120, 32, 32, 0xffffff);
    this.physics.add.existing(this.player);
    this.player.body.setCollideWorldBounds(true);

    this.physics.add.collider(this.player, ground);
    this.physics.add.collider(this.player, base1);
    this.physics.add.collider(this.player, base2);
    this.physics.add.collider(this.player, this.bridgeA);
    this.physics.add.collider(this.player, this.bridgeB);

    this.switchObj = this.add.rectangle(340, 300, 22, 14, 0xff3b3b);
    this.physics.add.existing(this.switchObj, true);

    this.goal = this.add.rectangle(720, 190, 18, 18, 0xffd34d);
    this.physics.add.existing(this.goal, true);

    this.exitZone = this.add.rectangle(770, 120, 70, 40, 0x20ff9a);
    this.exitZone.setAlpha(0.25);
    this.physics.add.existing(this.exitZone, true);

    // Laser "dummy image": si no tienes textura "__laser__", puede fallar.
    // Lo mantenemos pero lo hacemos seguro: si no existe textura, usamos un rectángulo con body.
    if (this.textures && this.textures.exists("__laser__")) {
      this.laser = this.physics.add.image(220, H - 70, "__laser__");
      this.laser.setVisible(false);
      this.laser.body.setAllowGravity(false);
      this.laser.body.setImmovable(true);
      this.laser.body.setSize(70, 10, true);
      this.laser.setVelocityX(160);
      this.laser.setBounce(1, 1);
      this.laser.setCollideWorldBounds(true);

      const laserRect = this.add.rectangle(220, H - 70, 70, 10, 0xff2d88);
      this.laser.__rect = laserRect;

      this.physics.add.overlap(this.player, this.laser, () =>
        this.scene.restart()
      );
    } else {
      // Alternativa 100% Phaser Arcade con rectángulo
      this.laser = this.add.rectangle(220, H - 70, 70, 10, 0xff2d88);
      this.physics.add.existing(this.laser);
      this.laser.body.setAllowGravity(false);
      this.laser.body.setImmovable(true);
      this.laser.body.setCollideWorldBounds(true);
      this.laser.body.setBounce(1, 1);
      this.laser.body.setVelocityX(160);

      this.physics.add.overlap(this.player, this.laser, () =>
        this.scene.restart()
      );
    }

    this.physics.add.overlap(this.player, this.switchObj, () => {
      if (this.switchLock) return;
      this.switchLock = true;
      this.time.delayedCall(250, () => (this.switchLock = false));
      this.toggleState();
    });

    this.physics.add.overlap(this.player, this.goal, () => {
      if (this.goalTaken) return;
      this.goalTaken = true;
      this.goal.destroy();
      this.hudMsg.setText("OBJETIVO CONSEGUIDO");
      this.updateExitVisual();
    });

    this.physics.add.overlap(this.player, this.exitZone, () => {
      if (!this.goalTaken) return;
      if (!this.switchOn) return;
      this.showWin();
    });

    this.cursors = this.input.keyboard.createCursorKeys();
    this.keyR = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R);

    this.hudTop = this.add.text(18, 14, "", {
      fontFamily: "Arial",
      fontSize: "18px",
      color: "#e6f0ff",
    });

    this.hudMsg = this.add.text(
      18,
      40,
      "Activa el interruptor para cambiar el mapa",
      {
        fontFamily: "Arial",
        fontSize: "18px",
        color: "#ffd34d",
      }
    );

    this.add.text(18, 66, "R reinicia", {
      fontFamily: "Arial",
      fontSize: "16px",
      color: "#9fb3ff",
    });

    this.updateHud();
  }

  update() {
    if (Phaser.Input.Keyboard.JustDown(this.keyR)) {
      this.scene.restart();
      return;
    }

    // Si era la versión image con rect, acompasamos el rectángulo visual
    if (this.laser && this.laser.__rect) {
      this.laser.__rect.x = this.laser.x;
      this.laser.__rect.y = this.laser.y;
    }

    this.updateHud();

    if (this.winLayer) {
      if (Phaser.Input.Keyboard.JustDown(this.keyEnter)) {
        this.scene.start("Level3");
      }
      return;
    }

    if (this.cursors.left.isDown) this.player.body.setVelocityX(-220);
    else if (this.cursors.right.isDown) this.player.body.setVelocityX(220);
    else this.player.body.setVelocityX(0);

    const jump =
      Phaser.Input.Keyboard.JustDown(this.cursors.up) ||
      Phaser.Input.Keyboard.JustDown(this.cursors.space);

    if (jump && this.player.body.blocked.down)
      this.player.body.setVelocityY(-420);

    if (this.player.y > H + 80) this.scene.restart();
  }

  toggleState() {
    this.switchOn = !this.switchOn;
    this.switchObj.fillColor = this.switchOn ? 0x20ff9a : 0xff3b3b;

    this.bridgeA.body.enable = !this.switchOn;
    this.bridgeA.setAlpha(this.switchOn ? 0.2 : 1);

    this.bridgeB.body.enable = this.switchOn;
    this.bridgeB.setAlpha(this.switchOn ? 1 : 0.2);

    this.updateExitVisual();
  }

  updateExitVisual() {
    const ok = this.goalTaken && this.switchOn;
    this.exitZone.setAlpha(ok ? 0.9 : 0.25);
  }

  updateHud() {
    this.hudTop.setText(
      `NIVEL 2  |  OBJETIVO: ${this.goalTaken ? "SÍ" : "NO"}  |  ESTADO: ${
        this.switchOn ? "ON" : "OFF"
      }`
    );
  }

  showWin() {
    if (this.winLayer) return;

    this.player.body.setVelocity(0, 0);
    this.player.body.moves = false;

    const bg = this.add
      .rectangle(W / 2, H / 2, 600, 260, 0x111a2e)
      .setAlpha(0.98);

    const t1 = this.add
      .text(W / 2, H / 2 - 75, "NIVEL 2 COMPLETADO", {
        fontFamily: "Arial",
        fontSize: "28px",
        color: "#20ff9a",
      })
      .setOrigin(0.5);

    const t2 = this.add
      .text(W / 2, H / 2 - 35, "Pulsa ENTER para ir al Nivel 3", {
        fontFamily: "Arial",
        fontSize: "18px",
        color: "#e6f0ff",
      })
      .setOrigin(0.5);

    const t3 = this.add
      .text(W / 2, H / 2 + 10, "Pulsa R para reiniciar", {
        fontFamily: "Arial",
        fontSize: "18px",
        color: "#9fb3ff",
      })
      .setOrigin(0.5);

    this.keyEnter = this.input.keyboard.addKey(
      Phaser.Input.Keyboard.KeyCodes.ENTER
    );

    this.winLayer = { bg, t1, t2, t3 };
  }
}

// ======================
// NIVEL 3 (llaves + plataformas móviles + puerta)
// ======================
class Level3 extends Phaser.Scene {
  constructor() {
    super("Level3");
  }

  create() {
    this.keysTaken = 0;
    this.doorOpen = false;
    this.winLayer = null;

    const ground = this.add.rectangle(W / 2, H - 20, W, 40, 0x2b395f);
    this.physics.add.existing(ground, true);

    const p1 = this.add.rectangle(160, 380, 160, 20, 0x2b395f);
    const p2 = this.add.rectangle(360, 310, 160, 20, 0x2b395f);
    const p3 = this.add.rectangle(600, 240, 160, 20, 0x2b395f);
    [p1, p2, p3].forEach((p) => this.physics.add.existing(p, true));

    this.moverA = this.add.rectangle(260, 200, 120, 18, 0x20a0ff);
    this.physics.add.existing(this.moverA);
    this.moverA.body.setImmovable(true);
    this.moverA.body.setAllowGravity(false);
    this.moverA.body
      .setVelocityX(120)
      .setBounce(1, 0)
      .setCollideWorldBounds(true);

    this.moverB = this.add.rectangle(520, 140, 120, 18, 0xff8c2d);
    this.physics.add.existing(this.moverB);
    this.moverB.body.setImmovable(true);
    this.moverB.body.setAllowGravity(false);
    this.moverB.body
      .setVelocityY(100)
      .setBounce(0, 1)
      .setCollideWorldBounds(true);

    this.player = this.add.rectangle(80, H - 120, 32, 32, 0xffffff);
    this.physics.add.existing(this.player);
    this.player.body.setCollideWorldBounds(true);

    [ground, p1, p2, p3, this.moverA, this.moverB].forEach((obj) =>
      this.physics.add.collider(this.player, obj)
    );

    this.keys = this.physics.add.staticGroup();
    const k1 = this.add.rectangle(360, 280, 14, 14, 0xffd34d);
    const k2 = this.add.rectangle(600, 210, 14, 14, 0xffd34d);
    this.physics.add.existing(k1, true);
    this.physics.add.existing(k2, true);
    this.keys.add(k1);
    this.keys.add(k2);

    this.physics.add.overlap(this.player, this.keys, (player, key) => {
      key.destroy();
      this.keysTaken++;
      this.updateHud();
      if (this.keysTaken >= 2) this.openDoor();
    });

    this.door = this.add.rectangle(740, 190, 30, 60, 0xff3b3b);
    this.physics.add.existing(this.door, true);

    this.exitZone = this.add
      .rectangle(740, 150, 80, 120, 0x20ff9a)
      .setAlpha(0.2);
    this.physics.add.existing(this.exitZone, true);

    this.physics.add.overlap(this.player, this.exitZone, () => {
      if (!this.doorOpen) return;
      this.showWin();
    });

    this.cursors = this.input.keyboard.createCursorKeys();
    this.keyR = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R);

    this.hud = this.add.text(18, 18, "", {
      fontFamily: "Arial",
      fontSize: "18px",
      color: "#e6f0ff",
    });
    this.updateHud();
  }

  openDoor() {
    this.doorOpen = true;
    this.door.fillColor = 0x20ff9a;
    this.door.body.enable = false;
    this.exitZone.setAlpha(0.9);
  }

  updateHud() {
    this.hud.setText(`NIVEL 3  |  LLAVES: ${this.keysTaken}/2`);
  }

  update() {
    if (Phaser.Input.Keyboard.JustDown(this.keyR)) {
      this.scene.restart();
      return;
    }

    if (this.winLayer) {
      if (Phaser.Input.Keyboard.JustDown(this.keyEnter)) {
        this.scene.start("Level4");
      }
      return;
    }

    if (this.cursors.left.isDown) this.player.body.setVelocityX(-220);
    else if (this.cursors.right.isDown) this.player.body.setVelocityX(220);
    else this.player.body.setVelocityX(0);

    const jump =
      Phaser.Input.Keyboard.JustDown(this.cursors.up) ||
      Phaser.Input.Keyboard.JustDown(this.cursors.space);

    if (jump && this.player.body.blocked.down)
      this.player.body.setVelocityY(-420);

    if (this.player.y > H + 80) this.scene.restart();
  }

  showWin() {
    if (this.winLayer) return;

    this.player.body.setVelocity(0, 0);
    this.player.body.moves = false;

    const bg = this.add
      .rectangle(W / 2, H / 2, 600, 260, 0x111a2e)
      .setAlpha(0.98);

    const t1 = this.add
      .text(W / 2, H / 2 - 70, "NIVEL 3 COMPLETADO", {
        fontFamily: "Arial",
        fontSize: "28px",
        color: "#20ff9a",
      })
      .setOrigin(0.5);

    const t2 = this.add
      .text(W / 2, H / 2 - 25, "Pulsa ENTER para ir al Nivel 4", {
        fontFamily: "Arial",
        fontSize: "18px",
        color: "#e6f0ff",
      })
      .setOrigin(0.5);

    const t3 = this.add
      .text(W / 2, H / 2 + 15, "Nivel 4: gravedad loca + portales", {
        fontFamily: "Arial",
        fontSize: "18px",
        color: "#ffd34d",
      })
      .setOrigin(0.5);

    const t4 = this.add
      .text(W / 2, H / 2 + 55, "Pulsa R para jugar otra vez", {
        fontFamily: "Arial",
        fontSize: "18px",
        color: "#9fb3ff",
      })
      .setOrigin(0.5);

    this.keyEnter = this.input.keyboard.addKey(
      Phaser.Input.Keyboard.KeyCodes.ENTER
    );

    this.winLayer = { bg, t1, t2, t3, t4 };
  }
}

// ======================
// NIVEL 4 (gravedad invertida + portales + glitch enemigo + 3 coleccionables)
// ======================
class Level4 extends Phaser.Scene {
  constructor() {
    super("Level4");
  }

  create() {
    this.winLayer = null;

    this.gravityDir = 1; // 1 normal, -1 invertida
    this.flipLock = false;
    this.portalLock = false;

    const ground = this.add.rectangle(W / 2, H - 20, W, 40, 0x2b395f);
    const ceiling = this.add.rectangle(W / 2, 20, W, 40, 0x2b395f);
    this.physics.add.existing(ground, true);
    this.physics.add.existing(ceiling, true);

    // Plataformas: SIN la del medio (p2)
    const p1 = this.add.rectangle(200, 340, 180, 18, 0x2b395f);
    const p3 = this.add.rectangle(600, 340, 180, 18, 0x2b395f);
    [p1, p3].forEach((p) => this.physics.add.existing(p, true));

    // Jugador
    this.player = this.add.rectangle(80, H - 120, 32, 32, 0xffffff);
    this.physics.add.existing(this.player);
    this.player.body.setCollideWorldBounds(true);

    [ground, ceiling, p1, p3].forEach((obj) =>
      this.physics.add.collider(this.player, obj)
    );

    // Pads de gravedad
    this.padA = this.add
      .rectangle(220, H - 70, 60, 14, 0xb56bff)
      .setAlpha(0.95);
    this.padB = this.add.rectangle(580, 70, 60, 14, 0xb56bff).setAlpha(0.95);
    this.physics.add.existing(this.padA, true);
    this.physics.add.existing(this.padB, true);

    this.physics.add.overlap(this.player, this.padA, () => this.flipGravity());
    this.physics.add.overlap(this.player, this.padB, () => this.flipGravity());

    // Portales (se mantiene, pero el nivel es más simple)
    this.portalA = this.add.rectangle(120, 90, 22, 22, 0x20a0ff).setAlpha(0.95);
    this.portalB = this.add
      .rectangle(720, H - 90, 22, 22, 0x20a0ff)
      .setAlpha(0.95);
    this.physics.add.existing(this.portalA, true);
    this.physics.add.existing(this.portalB, true);

    this.physics.add.overlap(this.player, this.portalA, () =>
      this.teleportTo(this.portalB)
    );
    this.physics.add.overlap(this.player, this.portalB, () =>
      this.teleportTo(this.portalA)
    );

    // Enemigo glitch (más lento para que sea fácil)
    this.glitch = this.add.rectangle(420, 170, 26, 14, 0xff2d88);
    this.physics.add.existing(this.glitch);
    this.glitch.body.setAllowGravity(false);
    this.glitch.body.setCollideWorldBounds(true);
    this.glitch.body.setBounce(1, 1);
    this.glitch.body.setVelocity(150, 110);

    this.physics.add.overlap(this.player, this.glitch, () =>
      this.scene.restart()
    );

    // ✅ Solo 2 monedas
    this.collected = 0;
    this.collectibles = this.physics.add.staticGroup();

    const c1 = this.add.rectangle(600, 310, 14, 14, 0xffd34d);
    const c2 = this.add.rectangle(200, 310, 14, 14, 0xffd34d);
    [c1, c2].forEach((c) => {
      this.physics.add.existing(c, true);
      this.collectibles.add(c);
    });

    this.physics.add.overlap(this.player, this.collectibles, (player, c) => {
      c.destroy();
      this.collected++;
      this.updateHud();
      if (this.collected >= 2) this.openExit();
    });

    // Salida
    this.exitOpen = false;
    this.exitZone = this.add
      .rectangle(760, 250, 70, 140, 0x20ff9a)
      .setAlpha(0.2);
    this.physics.add.existing(this.exitZone, true);

    this.physics.add.overlap(this.player, this.exitZone, () => {
      if (!this.exitOpen) return;
      this.showWin();
    });

    // Controles
    this.cursors = this.input.keyboard.createCursorKeys();
    this.keyR = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R);

    // HUD
    this.hud = this.add.text(18, 14, "", {
      fontFamily: "Arial",
      fontSize: "18px",
      color: "#e6f0ff",
    });
    this.hud2 = this.add.text(
      18,
      40,
      "Coge 2 monedas. Pads morados invierten gravedad.",
      {
        fontFamily: "Arial",
        fontSize: "18px",
        color: "#ffd34d",
      }
    );
    this.add.text(18, 66, "R reinicia", {
      fontFamily: "Arial",
      fontSize: "16px",
      color: "#9fb3ff",
    });

    this.applyGravity();
    this.updateHud();
  }

  updateHud() {
    const g = this.gravityDir === 1 ? "NORMAL" : "INVERTIDA";
    this.hud.setText(`NIVEL 4 | MONEDAS: ${this.collected}/2 | GRAVEDAD: ${g}`);
  }

  applyGravity() {
    this.player.body.setGravityY(900 * this.gravityDir);
    this.player.setAngle(this.gravityDir === -1 ? 180 : 0);
    this.updateHud();
  }

  flipGravity() {
    if (this.flipLock) return;
    this.flipLock = true;
    this.time.delayedCall(250, () => (this.flipLock = false));

    this.gravityDir *= -1;
    this.applyGravity();

    this.player.body.setVelocityY(120 * this.gravityDir);
  }

  teleportTo(targetPortal) {
    if (this.portalLock) return;
    this.portalLock = true;
    this.time.delayedCall(250, () => (this.portalLock = false));

    this.player.body.setVelocity(0, 0);
    this.player.x = targetPortal.x;
    this.player.y = targetPortal.y;
  }

  openExit() {
    this.exitOpen = true;
    this.exitZone.setAlpha(0.9);
    this.hud2.setText("SALIDA ABIERTA: llega a la zona verde");
  }

  update() {
    if (Phaser.Input.Keyboard.JustDown(this.keyR)) {
      this.scene.restart();
      return;
    }

    if (this.winLayer) return;

    if (this.cursors.left.isDown) this.player.body.setVelocityX(-220);
    else if (this.cursors.right.isDown) this.player.body.setVelocityX(220);
    else this.player.body.setVelocityX(0);

    const jump =
      Phaser.Input.Keyboard.JustDown(this.cursors.up) ||
      Phaser.Input.Keyboard.JustDown(this.cursors.space);

    const canJump =
      this.gravityDir === 1
        ? this.player.body.blocked.down
        : this.player.body.blocked.up;

    if (jump && canJump) {
      this.player.body.setVelocityY(-420 * this.gravityDir);
    }

    if (this.player.y > H + 120 || this.player.y < -120) this.scene.restart();
  }

  showWin() {
    if (this.winLayer) return;

    this.player.body.setVelocity(0, 0);
    this.player.body.moves = false;

    const bg = this.add
      .rectangle(W / 2, H / 2, 620, 240, 0x111a2e)
      .setAlpha(0.98);

    const t1 = this.add
      .text(W / 2, H / 2 - 50, "NIVEL 4 COMPLETADO", {
        fontFamily: "Arial",
        fontSize: "28px",
        color: "#20ff9a",
      })
      .setOrigin(0.5);

    const t2 = this.add
      .text(W / 2, H / 2, "Pulsa R para volver a jugar", {
        fontFamily: "Arial",
        fontSize: "18px",
        color: "#e6f0ff",
      })
      .setOrigin(0.5);

    this.winLayer = { bg, t1, t2 };
  }
}

const config = {
  type: Phaser.AUTO,
  width: W,
  height: H,
  backgroundColor: "#0b0f1a",
  physics: {
    default: "arcade",
    arcade: { gravity: { y: 900 }, debug: false },
  },
  scene: [Level1, Level2, Level3, Level4],
};

new Phaser.Game(config);
